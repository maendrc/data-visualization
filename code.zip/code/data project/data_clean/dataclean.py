import math
import os
import pandas as pd

class CustomDataFrame():
    __cells = {}
    __items =[]

    def __init__(self):
        self.__cells = {}

    def initHeader(self, header):
        for h in header:
            self.__cells[h] = []

    def appendCell(self, header, value):
        self.__cells[header].append(value)

    def format(self):
        temp = list(self.__cells.values())
        temp = list(zip(*temp))

        for item in temp:
            print(item)
            cdfi = CustomDataFrameItem()
            print("self.__cells.keys():", self.__cells.keys())
            for idx, key in enumerate(self.__cells.keys()):
                cdfi.setAttributeByHeader(key, item[idx])
            print(str(cdfi))
            self.__items.append(cdfi)

    def getMany(self, header, value):
        result = []
        for element in self.__items:
            if header in self.__cells:
                if value == element.getAttributeByHeader(header):
                    result.append(element)
            else:
                return None
        return result

    def __repr__(self):
        return str(self.__cells)

class CustomDataFrameItem():
    __name = ""
    __cost = 0
    __gender = ""
    __prime = ""
    __rating = 0

    def getAttributeByHeader(self, header):
        if header.lower() == 'name':
            return self.__name
        if header.lower() == 'cost':
            return self.__cost
        if header.lower() == 'used_by':
            return self.__gender
        if header.lower() == 'prime':
            return self.__prime
        if header.lower() == 'rating':
            return self.__rating

    def setAttributeByHeader(self, header, val):
        if header.lower() == 'name':
            self.setName(val)
        if header.lower() == 'cost':
            self.setCost(val)
        if header.lower() == 'used_by':
            self.setGender(val)
        if header.lower() == 'prime':
            self.setPrime(val)
        if header.lower() == 'rating':
            self.setRating(val)

    def setName(self, name):
        self.__name = name

    def setCost(self, cost):
        self.__cost = cost

    def setGender(self, gender):
        self.__gender = gender

    def setPrime(self, prime):
        self.__prime = prime
   
    def setRating(self, rating):
        self.__rating = rating

    def has_all_properties(self):
        return bool(self.__name and not math.isnan(self.__cost) and self.__gender and self.__prime and not math.isnan(self.__rating))

    def clean(self,wanted_cost,wanted_gender,wanted_prime,wated_rating):
        return bool(self.__name and self.__gender == wanted_gender and self.__cost <= wanted_cost and self.__prime == wanted_prime and self.__rating <= wanted_rating )

    def __init__(self):
        self.__name = ""
        self.__cost = 0
        self.__gender = ""
        self.__prime = ""
        self.__rating = 0

    def __eq__(self, other):
        return (self.__name == other.__name and self.__cost == other.__cost and self.__gender == other.__gender and self.__prime == other.__prime and self.__rating == other.__prime)
    def __hash__(self):
        return hash((self.__name, self.__cost, self.__gender, self.__prime, self.__rating))

    def __repr__(self):
        return f"CustomDataFrameItem({self.__name},{self.__cost},{self.__gender},{self.__prime}, {self.__rating})"

    def tuple(self):
        return self.__name, self.__cost, self.__gender, self.__prime, self.__rating

class Util():
    def __init__(self):
        pass

    def read_excel_by_filename(self, filename, cdf):
        df = pd.DataFrame()
        df = df.append(pd.read_excel(filename), ignore_index=True)
        df = df.where(df.notnull(), None)
        cdf.initHeader(df.columns.values)
        for idxRow, val in enumerate(df.values):
            for idxCol, cell in enumerate(val):
                if isinstance(cell, float) and math.isnan(cell):
                    cell = 0.0
                cdf.appendCell(df.columns.values[idxCol], cell)
        return cdf

    def read_excels(self, cdf):
        cwd = os.path.abspath('')
        files = os.listdir(cwd)
        for file in files:
            if file.endswith('.XLSX'):
                self.read_excel_by_filename(file, cdf)
        return cdf

    def write_cdf_to_excel(self, where, data):
        title = ['name', 'cost', 'gender', 'prime', 'rating']
        output = pd.DataFrame(data, columns = title)
        output.to_excel(where, index = False, header = True)

class Program():
    __cdf = None
    __util = None
    __cdfi = None
    def __init__(self):
        self.__cdf = CustomDataFrame()
        self.__util = Util()
        self.__cdfi = CustomDataFrameItem()
    def run(self):
        self.__cdf = self.__util.read_excels(self.__cdf)
        self.__cdf.format()
        result = self.__cdf.getMany('prime', 'yes')
        print(result)
        t_list = [obj.tuple() for obj in result]
        output = self.__util.write_cdf_to_excel('clean_data.xlsx',t_list)

if __name__ == "__main__":
    p = Program()
    p.run()

