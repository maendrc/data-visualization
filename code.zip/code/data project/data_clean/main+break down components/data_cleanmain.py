from editdataframe import CustomDataFrameItem
from program import Program

if __name__ == "__main__":
    p = Program()
    p.run()
