from util import Util
from customdataframe import CustomDataFrame
from editdataframe import CustomDataFrameItem
class Program():
    __cdf = None
    __util = None
    __cdfi = None
    def __init__(self):
        self.__cdf = CustomDataFrame()
        self.__util = Util()
        self.__cdfi = CustomDataFrameItem()
    def run(self):
        self.__cdf = self.__util.read_excels(self.__cdf)
        self.__cdf.format()
        result = self.__cdf.getMany('prime', 'yes')
        print(result)
        t_list = [obj.tuple() for obj in result]
        output = self.__util.write_cdf_to_excel('clean_data.xlsx',t_list)