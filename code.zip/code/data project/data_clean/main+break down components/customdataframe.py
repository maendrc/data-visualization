from editdataframe import CustomDataFrameItem

class CustomDataFrame():
    # {'cost':[55, 10, 30], name:[a, b, c], prime:[y, n, y]}

    # ['cost', 'name','used_by', 'prime']
    __cells = {}
    __items = []

    def __init__(self):
        self.__cells = {}

    def initHeader(self, header):
        for h in header:
            self.__cells[h] = []

    def appendCell(self, header, value):
        self.__cells[header].append(value)

    def format(self):
        temp = list(self.__cells.values())
        temp = list(zip(*temp))

        for item in temp:
            print(item)
            cdfi = CustomDataFrameItem()
            print("self.__cells.keys():", self.__cells.keys())
            for idx, key in enumerate(self.__cells.keys()):
                cdfi.setAttributeByHeader(key, item[idx])
            print(str(cdfi))
            self.__items.append(cdfi)

    def getMany(self, header, value):
        result = []
        for element in self.__items:
            if header in self.__cells:
                if value == element.getAttributeByHeader(header):
                    result.append(element)
            else:
                return None
        return result

    def __repr__(self):
        return str(self.__cells)