import os
import pandas as pd
import math
from editdataframe import CustomDataFrameItem

class Util():
    def __init__(self):
        self.__cdfi = CustomDataFrameItem()

    def read_excel_by_filename(self, filename, cdf):
        df = pd.DataFrame()
        df = df.append(pd.read_excel(filename), ignore_index=True)
        df = df.where(df.notnull(), None)
        cdf.initHeader(df.columns.values)
        for idxRow, val in enumerate(df.values):
            for idxCol, cell in enumerate(val):
                if isinstance(cell, float) and math.isnan(cell):
                    cell = 0.0
                cdf.appendCell(df.columns.values[idxCol], cell)
        return cdf

    def read_excels(self, cdf):
        cwd = os.path.abspath('')
        files = os.listdir(cwd)
        for file in files:
            if file.endswith('.XLSX'):
                self.read_excel_by_filename(file, cdf)
        return cdf

    def write_cdf_to_excel(self, where, data):
        title = ['name', 'cost', 'gender', 'prime', 'rating']
        output = pd.DataFrame(data, columns = title)
        output.to_excel(where, index = False, header = True)