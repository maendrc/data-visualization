import math 

class CustomDataFrameItem():
    __name = ""
    __cost = 0
    __gender = ""
    __prime = ""
    __rating = 0

    def getAttributeByHeader(self, header):
        if header.lower() == 'name':
            return self.__name
        if header.lower() == 'cost':
            return self.__cost
        if header.lower() == 'used_by':
            return self.__gender
        if header.lower() == 'prime':
            return self.__prime
        if header.lower() == 'rating':
            return self.__rating

    def setAttributeByHeader(self, header, val):
        if header.lower() == 'name':
            self.setName(val)
        if header.lower() == 'cost':
            self.setCost(val)
        if header.lower() == 'used_by':
            self.setGender(val)
        if header.lower() == 'prime':
            self.setPrime(val)
        if header.lower() == 'rating':
            self.setRating(val)

    def setName(self, name):
        self.__name = name

    def setCost(self, cost):
        self.__cost = cost

    def setGender(self, gender):
        self.__gender = gender

    def setPrime(self, prime):
        self.__prime = prime
   
    def setRating(self, rating):
        self.__rating = rating

    def has_all_properties(self):
        return bool(self.__name and not math.isnan(self.__cost) and self.__gender and self.__prime and not math.isnan(self.__rating))

    def clean(self,wanted_cost,wanted_gender,wanted_prime,wated_rating):
        return bool(self.__name and self.__gender == wanted_gender and self.__cost <= wanted_cost and self.__prime == wanted_prime and self.__rating <= wanted_rating )

    def __init__(self):
        self.__name = ""
        self.__cost = 0
        self.__gender = ""
        self.__prime = ""
        self.__rating = 0

    def __eq__(self, other):
        return (self.__name == other.__name and self.__cost == other.__cost and self.__gender == other.__gender and self.__prime == other.__prime and self.__rating == other.__prime)
    def __hash__(self):
        return hash((self.__name, self.__cost, self.__gender, self.__prime, self.__rating))

    def __repr__(self):
        return f"CustomDataFrameItem({self.__name},{self.__cost},{self.__gender},{self.__prime}, {self.__rating})"

    def tuple(self):
        return self.__name, self.__cost, self.__gender, self.__prime, self.__rating

