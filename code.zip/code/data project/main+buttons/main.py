from button import screen

if __name__ == "__main__":
    root = screen()
    root.mainloop()