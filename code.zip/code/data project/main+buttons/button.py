import tkinter as tk
from tkinter import ttk
import os
Large_Font= ('Helvetica 17 bold')

class screen (tk.Tk):
    
    def __init__(self):

        tk.Tk.__init__(self)
        tk.Tk.wm_title(self, "data project")

        container = tk.Frame(self)
        container.pack(side="top",fill="both", expand = True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}        
        for i in (home, page_one, page_two):
            frame = i(container, self)
            self.frames[i] = frame
            frame.grid(row=0, column=0, sticky="nswe")
        self.show_frame(home)
    
    def show_frame(self, cont): 
        frame = self.frames[cont]
        frame.tkraise()

    def exit(self):
        tk.Tk.destroy(self)

    def import_other_pyfile(self, where):
        os.system(where)

    def open_file(self, file):
        os.startfile(file)

class home (tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text = "Start page", font = Large_Font)
        label.pack(pady=10,padx=10)
        
        dataclean = ttk.Button(self, text= "Data_Clean", command=lambda: controller.show_frame(page_two))
        dataclean.pack()
        
        graph = ttk.Button(self, text= "Graph", command=lambda: controller.show_frame(page_one))
        graph.pack()
         
        leave = ttk.Button(self, text= "Leave", command= lambda: controller.exit())
        leave.pack()

class page_one(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text = "Graph to data from clean_data excel", font = Large_Font)
        label.pack(pady=10,padx=10)

        back = tk.Button(self, text= "return_home", command=lambda: controller.show_frame(home))
        back.pack()
        
        graph = tk.Button(self, text= "graph_data", command=lambda: controller.import_other_pyfile('graph_main.py'))
        graph.pack()

class page_two(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text = "Press button to clean; see result excel", font = Large_Font)
        label.pack(pady=10,padx=10)

        back = tk.Button(self, text= "return_home", command=lambda: controller.show_frame(home))
        back.pack()

        dataclean = ttk.Button(self, text= "Clean", command=lambda: controller.import_other_pyfile('data_cleanmain.py'))
        dataclean.pack()

        see_result = ttk.Button(self, text= "see_result", command=lambda: controller.open_file('clean_data.xlsx'))
        see_result.pack() 