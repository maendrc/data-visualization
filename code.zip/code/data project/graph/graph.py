import pandas as pd

import tkinter as tk
from tkinter import ttk
from button import screen

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

class Util():
    def __init__(self):
        pass
 
    def exit_program(self, where):
        where.destroy()

    def graph(self, df, title_name, x, y, type, base):
        figure = plt.Figure(figsize=(4,5), dpi=100)
        ax = figure.add_subplot(111)
        bar = FigureCanvasTkAgg(figure, base)
        bar.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH)
        df = df[[x,y]].groupby(x).sum()

        if type == 'line':
            df.plot(kind= type, legend=True, ax=ax, color='r',marker='o', fontsize=10)
        if type == 'bar':
            df.plot(kind= type, legend=True, ax=ax, color='b', fontsize=10)


class Program():
    __util = None
    def __init__(self):
        self.__util = Util()
    def run(self):
        df = pd.read_excel (r'C:\Users\Zhang\Desktop\clean_data.xlsx')
        root = tk.Tk()
        root.wm_title("graph")
        ttk.Button(root, text= "Exit to go back to main", command= lambda: self.__util.exit_program(root)).pack()
        graph1 = self.__util.graph(df, 'product Vs. cost', 'name', 'cost', 'bar', root)
        graph2 = self.__util.graph(df, 'Cost Vs. Rating', 'cost', 'rating', 'line', root)
        root.mainloop()