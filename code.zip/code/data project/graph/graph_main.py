from graph import Program

if __name__ == "__main__":
    p = Program()
    p.run()