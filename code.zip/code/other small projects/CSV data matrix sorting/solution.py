import csv

def sortArr(arr):
    for i in range(0,len(arr)):
        for j in range (i,len(arr)):
            if arr[i]>arr[j]:
                 temp = arr[i]
                 arr[i] = arr[j]
                 arr[j] = temp
    return arr

def convert1Dinto2DArr(arr, numRow, numCol, numTotal):
    resultArr = []
    for i in range(0, numRow):
        temp = []
        for j in range(0, numCol):
            temp.append(arr[j+numCol*i])
        resultArr.append(temp)
    return resultArr

def process(input):
    numRow = len(input)
    numCol = len(input[0])
    flattenArr = [item for sublist in input for item in sublist]
    numTotal = len(flattenArr)
    # flatten_list = lambda y:[x for a in y for x in flatten_list(a)] if type(y) is list else [y]
    # print("Flattened List ",flatten_list(input))
    sortedArr = sortArr(flattenArr)
    return convert1Dinto2DArr(sortedArr, numRow, numCol, numTotal)

def readFromCSV(fileName):
    array = []
    with open(fileName) as csvfile:
        reader = csv.reader(csvfile, quoting=csv.QUOTE_NONNUMERIC)
        for line in reader:
            if len(line) > 0:
                subArray = []
                for x in line:
                    if not isinstance(x, str) and x is not None and x != '':
                        subArray.append(x)
                array.append(subArray)
    return array

def writeToCSV(fileName, arr):
    with open(fileName, 'w', newline='') as out:
        for row in arr:
            for col in row:
                out.write('{0},'.format(int(col)))
            out.write('\n')

if __name__ == "__main__":
    inputCSV = readFromCSV('error_input.csv')
    resultArr = process(inputCSV)
    outputCSV = writeToCSV('output.csv', resultArr)
