import csv
key_word = 'qwe'
word_counter = 0
line_counter = 0
with open('demo.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for line in csv_reader:
        print(line)
        line_counter +=1  
        for ele in line:
            if key_word in str(ele):
                word_counter = word_counter + 1
         
print(f'have {word_counter} qwes.')
print(f'have {line_counter} lines.')
